angular.module('starter.controllers', [])

.controller('TabsCtrl', function($scope, $rootScope, $state, $ionicPopover, $window) {

  // This is to hide the tabs on the login/signup pages
  $rootScope.$on('$ionicView.beforeEnter', function() {
    $rootScope.hideTabs = false;
    if ($state.current.name === 'tab.login') {
      $rootScope.hideTabs = true;
    }
    if ($state.current.name === 'tab.intro') {
      $rootScope.hideTabs = true;
    }
  });
})

.controller('LoginCtrl', function($scope, $ionicModal, $state, $window) {
  $scope.currentDate = new Date();

  $scope.signUp = function() {
    $state.go('tab.dash');
    $scope.closeModal();
  };

  $scope.datePickerCallback = function (val) {

    //$scope.dob = val;
      if(typeof(val)==='undefined'){      
          console.log('Date not selected');
      }else{
          console.log('Selected date is : ', val);
      }
  };

  $ionicModal.fromTemplateUrl('templates/signup.html', {
    scope: $scope,
    // animation: 'slide-in-up',
    animation: 'slide-in-right',
    hardwareBackButtonClose: true
  }).then(function(modal) {
    $scope.modal = modal;
  });
  $ionicModal.fromTemplateUrl('templates/forget-pass.html', {
    scope: $scope,
    animation: 'slide-in-up',
    hardwareBackButtonClose: true
  }).then(function(modal) {
    $scope.modalPass = modal;
  });

  $scope.openModal = function() {
    $scope.modal.show();
  };
  $scope.openPass = function() {
    $scope.modalPass.show();
  };
  $scope.closeModal = function() {
    $scope.modal.hide();
  };
  $scope.closePass = function() {
    $scope.modalPass.hide();
  };
  //Cleanup the modal when we're done with it!
  $scope.$on('$destroy', function() {
    $scope.modal.remove();
    $scope.modalPass.remove();
  });
  // Execute action on hide modal
  $scope.$on('modal.hidden', function() {
    // Execute action
  });
  // Execute action on remove modal
  $scope.$on('modal.removed', function() {
    // Execute action
  });
})
.controller('DashCtrl', function($scope, $state) {})

.controller('AccountCtrl', function($scope) {
  $scope.changePhoto = function() {
    alert('Change Profile Photo');
  }
})

.controller('SettingsCtrl', function($scope) {});
